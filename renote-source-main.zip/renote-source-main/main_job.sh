# # source /home/wname/Documents/github/renote-source/venv_renote/bin/activate.fish
# ollama serve &

# # echo "ollama is running"

# exec_dir_path = $TMPDIR/wname_code/renote_main/a1/b1/c1

# mkdir -p $exec_dir_path

# cd $exec_dir_path

# nb_dir_path=/projects/semcache/nb_tname_datasets/dataset1
# results_cache_path=/home/wname/Documents/github/renote-source/renote_analysis_caches/machine1_dataset1/
# resume=1
# source_envs_path=$TMPDIR/renote_nodes_venvs/machine1/
# backupenvs_path=$TMPDIR/renote_nodes_venvs/copied_envs/machine1/
# num_process=32

# python /home/wname/Documents/github/renote-source/renote_utils/main_renote.py --nb_dir_path $nb_dir_path --results_cache_path $results_cache_path --resume $resume --source_envs_path $source_envs_path --backupenvs_path $backupenvs_path --num_process $num_process
